<?php $notas = array (
  'emi-16996377' => 5795,
);

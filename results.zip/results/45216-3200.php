<?php $notas = array (
  'emi-15504812' => 3200,
);

<?php $notas = array (
  'emi-14648180' => 7680,
);

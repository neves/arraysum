<?php $notas = array (
  'emi-13659701' => 1123,
  'emi-13659693' => 9385,
);

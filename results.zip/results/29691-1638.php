<?php $notas = array (
  'emi-9326813' => 1638,
);

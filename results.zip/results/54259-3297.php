<?php $notas = array (
  'emi-15993155' => 297,
  'emi-15993144' => 3000,
);

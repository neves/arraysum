<?php $notas = array (
  'emi-14449691' => 66310,
);

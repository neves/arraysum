<?php $notas = array (
  'emi-12497730' => 6000,
);

<?php $notas = array (
  'emi-15826696' => 974,
  'emi-15826721' => 22140,
);

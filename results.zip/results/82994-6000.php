<?php $notas = array (
  'emi-17135610' => 6000,
);

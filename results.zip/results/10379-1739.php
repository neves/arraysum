<?php $notas = array (
  'emi-13433089' => 1739,
);

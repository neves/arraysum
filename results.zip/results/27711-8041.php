<?php $notas = array (
  'emi-13769597' => 8041,
);

<?php $notas = array (
  'emi-12493334' => 74412,
);

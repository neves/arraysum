<?php $notas = array (
  'emi-13664603' => 5332,
);

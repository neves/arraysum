<?php $notas = array (
  'emi-14245532' => 33800,
);

<?php $notas = array (
  'emi-12496726' => 11100,
);

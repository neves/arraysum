<?php $notas = array (
  'emi-14818502' => 3995,
  'emi-14818503' => 5295,
);

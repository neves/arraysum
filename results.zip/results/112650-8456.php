<?php $notas = array (
  'rec-4913029' => 3300,
  'rec-4913014' => 5156,
);

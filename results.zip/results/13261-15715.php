<?php $notas = array (
  'emi-13645084' => 15715,
);

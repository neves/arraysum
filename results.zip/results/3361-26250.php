<?php $notas = array (
  'emi-12865978' => 26250,
);

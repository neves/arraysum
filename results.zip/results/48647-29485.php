<?php $notas = array (
  'emi-13400818' => 29485,
);

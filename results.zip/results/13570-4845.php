<?php $notas = array (
  'emi-13653561' => 4845,
);

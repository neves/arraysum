<?php $notas = array (
  'emi-14686793' => 1710,
  'emi-14686792' => 5235,
);

<?php $notas = array (
  'emi-13451445' => 285015,
);

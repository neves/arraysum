<?php $notas = array (
  'emi-16366505' => 1872,
);

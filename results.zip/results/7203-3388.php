<?php $notas = array (
  'emi-13449267' => 894,
  'emi-13449274' => 2494,
);

<?php $notas = array (
  'emi-14371864' => 9000,
);

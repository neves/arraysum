<?php $notas = array (
  'emi-13034335' => 17750,
);

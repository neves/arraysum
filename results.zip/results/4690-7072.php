<?php $notas = array (
  'emi-13385729' => 7072,
);

<?php $notas = array (
  'emi-13594800' => 35760,
);

<?php $notas = array (
  'emi-14676186' => 6000,
);

<?php $notas = array (
  'emi-15963276' => 5361,
);

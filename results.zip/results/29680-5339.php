<?php $notas = array (
  'emi-14677738' => 2400,
  'emi-14677744' => 2939,
);

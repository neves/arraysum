<?php $notas = array (
  'emi-14228271' => 91029,
);

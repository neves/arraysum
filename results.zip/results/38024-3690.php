<?php $notas = array (
  'emi-14862669' => 3690,
);

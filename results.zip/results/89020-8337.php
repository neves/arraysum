<?php $notas = array (
  'emi-17188975' => 8337,
);

<?php $notas = array (
  'emi-16367973' => 22882,
);

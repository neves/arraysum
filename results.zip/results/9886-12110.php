<?php $notas = array (
  'emi-13512825' => 12110,
);

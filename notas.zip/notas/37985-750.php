<? $notas = array (
  'emi-9412234' => 9000,
); ?>